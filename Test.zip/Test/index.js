const mongoose = require('mongoose')
    .connect('mongodb+srv://Ajmal:7339055264@cluster0.ibcsg5s.mongodb.net/?retryWrites=true&w=majority')
    .then(() => {
        console.log('your DB is ready...')
    })
const user = require('./Schemas/user');
const layout = require('./Schemas/layout');

const express = require('express');
const bodyParser = require('body-parser');
const { log } = require('console');
const app = express();
app.listen(8000, () => {
    console.log("helloooo everyone");
});
app.use(bodyParser.json());

//for user 

app.post('/user', async (req, res, next) => {
    const user_info = await new user(req.body);
    console.log(user_info);
    user_info.save();
    res.status(200).send(user_info)
})

//for layout

//1.create layout
app.post('/layout', async (req, res, next) => {
    const layout_info = await new layout(req.body);
    console.log(layout_info);
    layout_info.save();
    res.status(200).send(layout_info)
})

//2.get all layouts
app.get('/getlayout', async (req, res, next) => {
    const Get_all_layout = await layout.find({}).populate('insertedby', 'updatedby');
    console.log(Get_all_layout);
    res.status(200).send(Get_all_layout);
})



//3.get layout  particukar id
app.get('/getonelayout/:id', async (req, res, next) => {
    const Get_one_layout = await layout.findOne({ _id: req.params.id }).populate('insertedby', 'updatedby');
    console.log(Get_one_layout);
    return res.status(200).send(Get_one_layout);
})

//4.update the layout by id
app.put('/getonelayout/:id/inactivate', async (req, res, next) => {
    const Update_layout = await layout.findByIdAndUpdate({ _id: req.params.id }, { $set: { ...req.body, status: 'INACTIVE' } }, { new: true });
    console.log(Update_layout);
    if (!Update_layout) {
        return res.status(404).send('Employee not found or already deleted');
    }
    res.status(200).send(Update_layout);
});

//5.delete the layout by id
app.delete('/layout/:id', async (req, res, next) => {
    const Delete_layout = await layout.deleteOne({ _id: req.params.id });
    console.log(Delete_layout);
    res.status(200).send("sucessfulley deleted");
})
