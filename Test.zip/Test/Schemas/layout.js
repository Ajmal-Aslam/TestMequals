const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Layout = new Schema({
    layoutname: {
        type: String,
        required: true,
        unique: true
    },
    layoutcode: {
        type: String,
        required: true
    },
    description: {
        type: String
    },
    status: {
        type: String,
        enum: ['ACTIVE', 'INACTIVE'],
        default: 'ACTIVE',
    },
    insertedby: [{ type: mongoose.Schema.Types.ObjectId, ref: 'USER_ABT_INFO' }],
    updatedby: [{ type: mongoose.Schema.Types.ObjectId, ref: 'USER_ABT_INFO' }],
    createdat: {
        type: Date,
        default: Date.now,
    }

})

const layout = mongoose.model("LAYOUT_INFO", Layout);
module.exports = layout;